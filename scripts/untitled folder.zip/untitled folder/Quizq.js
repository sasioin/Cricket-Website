let MCQS = [{
    question: "What colour are cricket balls?",
    choice1: "Blue",
    choice2: "Yellow",
    choice3: "Neon Green",
    choice4: "Red",
    answer: 3
},
{
    question: "How many innings are there in a game of cricket?",
    choice1: "1",
    choice2: "2",
    choice3: "3",
    choice4: "4",
    answer: 2
},
{
    question: "How many players are there in a cricket team?",
    choice1: "9",
    choice2: "10",
    choice3: "11",
    choice4: "12",
    answer: 2
},
{
    question: "Which of these countries is cricket NOT the national sport?",
    choice1: "Australia",
    choice2: "England",
    choice3: "The Bahamas",
    choice4: "Brazil",
    answer: 3
},
{
    question: "How many overs are there in a one-day cricket match?",
    choice1: "10",
    choice2: "20",
    choice3: "50",
    choice4: "100",
    answer: 2
},
{
        question: "What is the name of the person who umpires a game of cricket?",
        choice1: "Referee",
        choice2: "Official",
        choice3: "Umpire",
        choice4: "Coach",
        answer: 2
},
{
    question: "What is the name of the protective gear worn by the batsman in cricket?",
    choice1: "Pads",
    choice2: "Gloves",
    choice3: "Helmet",
    choice4: "All of the above",
    answer: 3
},
{
    question: "What is the maximum number of overs in a game of cricket?",
    choice1: "20",
    choice2: "50",
    choice3: "100",
    choice4: "200",
    answer: 1
},
{
    question: "Which country has won the most Cricket World Cup titles?",
    choice1: "India",
    choice2: "Australia",
    choice3: "England",
    choice4: "South Africa",
    answer: 1
},
{
    question: "What is the name of the small, hard ball used in cricket?",
    choice1: "Soccer ball",
    choice2: "Baseball",
    choice3: "Tennis ball",
    choice4: "Cricket ball",
    answer: 3
}];